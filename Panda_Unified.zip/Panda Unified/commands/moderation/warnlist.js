const Discord = require('discord.js')
const db = require('quick.db')

module.exports = {

    commands: "warnlist",
    description: "View Warns of a member!",
    category: "moderation",
    callback: async(message, args, text, client) => {
        let target = message.author
        
      


        const list = await db.get(`${message.guild.id}_${target.id}warnsa.reason`)
        console.log(db.get(`${message.guild.id}_${target.id}warnsa.reason`))
        if (list && list.every(element => element === null)) {
            return message.reply('🧹 | You are super clean!')
        }
        if (list) {
            var i = 1
            const em = new Discord.MessageEmbed()
            .setAuthor(`🔨 | ${target.username}#${target.discriminator}`, `${message.guild.iconURL()}`)
            .setDescription(`All warnings for <@${target.id}>`)
            .setThumbnail(`${message.member.user.displayAvatarURL()}`)
            list.forEach(element => {
                
                if(element !== null){
                    em.addField(`Warning ${i} | Moderator: Hidden`, `Warn: \`${element}\``)

                    i++
                }

        });

        message.reply(em)
    } else {
        message.reply('🧹 | You are super clean!')
    }
    }

}