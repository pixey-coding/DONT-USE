const db = require('quick.db')

module.exports = {
    commands: "addq",
    description: "Add a question for your quiz",
    permissions: ['MANAGE_GUILD'],
    minArgs:4,
    expectedArgs: "<question> | correct option | wrong option1 | wrong option 2 | wrong option 3 ",
    callback: async(message, args, text, client) => {
        const question = text.split('|')
        
        const options = text.split('|')
        options.shift()
   
        db.push(`questions_${message.author.id}`, 
            {
                question: question[0],
                options
            }
        
        )
        
        console.log(await db.get(`questions_${message.author.id}`))
        message.channel.send('Question Added!')
    }
}