const { MessageEmbed } = require('discord.js')
const db = require('quick.db')
const leaderboard = require('../../db/leaderboard')

module.exports = {
    commands: "qstart",
    description: "Start the quiz!",
    permissions: ['MANAGE_GUILD'],
    callback: async(message, args, text, client) => {

        const allquestions = await db.get(`questions_${message.author.id}`)
        
        if (!allquestions || !allquestions[0]) return message.channel.send('Please add a few questions before starting the quiz!')
        
        leaderboard.deleteMany({ }).then(console.log('Deleted everything'))
        const sendQuestion = async(message, args, text, client) => {
            
            if (!allquestions[0]) clearInterval(af)
            function shuffle(array) {
                for (let i = array.length - 1; i > 0; i--) {
                  let j = Math.floor(Math.random() * (i + 1));
                  [array[i], array[j]] = [array[j], array[i]];
                }
              }
              const rightAns = allquestions[0].options[0]



             async function givePoints(message) {
                const reat = ["1️⃣", "2️⃣", "3️⃣", "4️⃣"]
                message.channel.send(`The correct answer was \`${rightAns}\``)
               const users = message.reactions.cache.get(reat[ans]).users.cache
               
               users.delete(message.author.id)
              
                users.forEach(async user => {
                    
                    if (users.first() == user) {
                        await leaderboard.findOneAndUpdate({
                            userId: user.id,
                            guildId: message.guild.id
                        }, {
                            userId: user.id,
                            guildId: message.guild.id,
                            $inc: {
                                received: 1,
                              },
                        }, {
                            upsert: true
                        })
                    }
                    if (!user.bot) {
                        await leaderboard.findOneAndUpdate({
                            userId: user.id,
                            guildId: message.guild.id
                        }, {
                            userId: user.id,
                            guildId: message.guild.id,
                            $inc: {
                                received: 1,
                              },
                        }, {
                            upsert: true
                        }).then( message.channel.send(`Added points to <@${user.id}>`))
                    
                    }
                })
    
              }
              
           
               shuffle(allquestions[0].options)
               const ans = allquestions[0].options.indexOf(rightAns)
           
                const answers = allquestions[0].options
                const questionEm = new MessageEmbed()   
                            .setColor('BLUE')
                            .setTitle(`${allquestions[0].question}`)
                            .setDescription(`:one: ${answers[0]} \n:two: ${answers[1]} \n :three: ${answers[2]} \n :four: ${answers[3]}`)
                            .setFooter(`Next question will be posted in 10 seconds.`)
              const react = ["1️⃣", "2️⃣", "3️⃣", "4️⃣"]
                message.channel.send(questionEm).then((message) => { 
                   
                    react.forEach(em =>  message.react(em))
                    setTimeout(givePoints, 10000, message)
                   
                })
                
                    
               
                allquestions.shift()

                await db.set(`questions_${message.author.id}`, allquestions)
        }
       const af = setInterval(sendQuestion, 1000, message, client)
       
       
        
    }

}