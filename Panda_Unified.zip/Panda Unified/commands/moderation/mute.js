
const { MessageEmbed } = require('discord.js')
const ms = require('ms')
module.exports = {

    commands: "mute",
    description: "Mute a member!",
    minArgs: 2,
    expectedArgs: "<member-mention> <time> <reason optional> ",
    permissions: ["MANAGE_MESSAGES"],
    permissionError: "Get the `MANAGE_MESSAGES` permission to run this command!",
    callback: async(message, args, text, client) => {
      const logs = client.channels.cache.get('806524112301195334')
        let member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
let time = args[1]
let reason = args.slice(2).join(' ')
let date = new Date().toLocaleString()
var muteRole = message.guild.roles.cache.find(r => r.name.toLowerCase() === 'muted')


if (!member) return noUser(message)

if (!reason) reason = 'Unspecified'

if (!time || isNaN(ms(time))) {
    let embed = new MessageEmbed()
        .setColor('RED')
        .setTitle('You have to specify the time (1s, 2h, 3d).')
    return message.channel.send(embed).then(msg => msg.delete({ timeout: 8000 }))
}

if (ms(time) > 1209600000) {
    let embed = new MessageEmbed()
        .setColor('RED')
        .setTitle('You cannot mute him for more than 14 days.')
    return message.channel.send(embed).then(msg => msg.delete({ timeout: 8000 }))
}

if (member === message.member) {
    let embed = new MessageEmbed()
        .setColor('RED')
        .setTitle('You cannot mute yourself.')
    return message.channel.send(embed).then(msg => msg.delete({ timeout: 8000 }))
}

if (member === message.guild.me) {
    let embed = new MessageEmbed()
        .setColor('RED')
        .setTitle('You cannot mute me.')
    return message.channel.send(embed).then(msg => msg.delete({ timeout: 8000 }))
}

if (member.roles.cache.has(muteRole)) {
    let embed = new MessageEmbed()
        .setColor('RED')
        .setTitle('That member is already muted.')
    return message.channel.send(embed).then(msg => msg.delete({ timeout: 8000 }))
}
const redis = require('../../features/redis')



  const redisKeyPrefix = 'muted-'

  redis.expire((message) => {
    if (message.startsWith(redisKeyPrefix)) {
      const split = message.split('-')

      const memberId = split[1]
      const guildId = split[2]

      const guild = client.guilds.cache.get(guildId)
      const member = guild.members.cache.get(memberId)

     

      member.roles.remove(muteRole)
    }
  })


  const giveRole = (member) => {

      member.roles.add(muteRole)
      
    
  }

  const onJoin = async (member) => {
    const { id, guild } = member

    const redisClient = await redis()
    try {
      redisClient.get(`${redisKeyPrefix}${id}-${guild.id}`, (err, result) => {
        if (err) {
          console.error('Redis GET error:', err)
        } else if (result) {
          giveRole(member)
        } else {
          console.log('The user is not muted')
        }
      })
    } finally {
      redisClient.quit()
    }
  }

  client.on('guildMemberAdd', (member) => {
    onJoin(member)
  })

    // !mute @ duration duration_type


  



    const { id } = member


  const asads = ms(time)/1000
    const targetMember = message.guild.members.cache.get(id)
    giveRole(targetMember)
  const mute = new MessageEmbed()
  
  .setColor('GREEN')
  .setTitle(`:mute: | Member ${member.user.tag} has been muted.`)
  .setDescription(`**Reason:** ${reason}\n**Time:** ${time}`)
  message.reply(mute)
  logs.send(mute)
    const redisClient = await redis()
    try {
      const redisKey = `${redisKeyPrefix}${id}-${message.guild.id}`

    
        redisClient.set(redisKey, 'true', 'EX', asads)
 
    } finally {
      redisClient.quit()
    }
  



    }

    //nNuay9QUJOc9NJ6LIGjrbjLmhaLdaIWf
    //redis-14244.c98.us-east-1-4.ec2.cloud.redislabs.com:14244
}
