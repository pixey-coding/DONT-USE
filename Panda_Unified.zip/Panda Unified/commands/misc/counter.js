const Discord = require('discord.js')
const ms = require('ms')
const pms = require('pretty-ms')
module.exports = {
    commands: 'counter',
    minArgs: 1,
    expectedArgs: '<time>',
     description: "Start a new counter!",
     permissions: ["MANAGE_MESSAGES"],
    callback: async (message, args) => {
        
        let time = ms(args[0])
        const a = pms(time)
       message.channel.send(`Time remaining: **__${a}__**`).then(counter => {
        time = time - 10000
        setInterval(function() {
            if (time > 0) {
                const b = pms(time)
               counter.edit(`Time remaining: **__${b}__**`)
                time = time - 10000
            } else {
                counter.edit('Countdown finished!')
            }
        }, 10000)

    })
       }
      

}