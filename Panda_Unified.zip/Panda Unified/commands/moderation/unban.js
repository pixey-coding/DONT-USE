const Discord = require('discord.js');

module.exports = {
    commands: "unban",
    category: "Moderation",
    description: "Unbans the banned user with the provided user ID",
    expectedArgs: `<User-ID> <Reason>`,
    minArgs: 2,
    permissions: ["BAN_MEMBERS"],
    category: "moderation",

    callback: async (message, args, text, client) => {

        const id = args[0];
        const Banned = await message.guild.fetchBans();
        const user = Banned.get(id).user;
        const Perms = ["BAN_MEMBERS" || "ADMINSTRATOR"] 
        const doggo = message.guild.members.cache.get(client.user.id);
        const logs = client.channels.cache.get('806524112301195334')
        
        if(!message.member.hasPermission(Perms)) 
        return message.reply(`:x: You do not have the permission to do that in order to unban someone you need to have permission **\`BAN_MEMBERS\`** or **\`ADMINISTRATOR\`**`)
        .then(msg => {
            msg.delete({ timeout: 20000 })
        });

        if(!doggo.hasPermission(Perms))
        return message.reply(`:x: I do not have permission to unban users pls enable permission **\`BAN_MEMBERS\`** or **\`ADMINSTRATOR\`** for me`)

        if(!user)
        return message.reply(`:x: Please provide a user ID of a banned person inorder to unban that user **\`+unban [Banned User's ID] [Reason]\`**`)

        if(user === client.user.id)
        return message.reply(`:x: Wait what ??!! am I even banned in this guild ?!!!`)

        if(!user === message.author.id) 
        return message.reply(`:x: Lmfao unbanning yourself if you are banned then how you are in this guild get banned and then ask someone to unban you !!`)

        const reason = args.slice(1).join(" ");




        await message.guild.members.unban(user, reason);

        const embed = new Discord.MessageEmbed()
        .setTitle('Unban !!')
        .setDescription(`:white_check_mark: Unbanned **\`${user.tag}\`**`)
        .addField('Reason', `${reason != "" ? reason : "-"}`, true)
        .addField('Unbanned By', `<@${message.member.id}> `, true)
        .setTimestamp()
       
        message.channel.send(embed)
        logs.send(embed)
    }

}