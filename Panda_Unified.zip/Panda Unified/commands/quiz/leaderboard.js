const { MessageEmbed } = require('discord.js')
const thanksSchema = require('../../db/leaderboard')



module.exports = {
  commands: 'leaderboard',
  description: "Shows the leaderboard of the quiz!",
  callback: async(message, args, tex, client) => {
    const guildId = message.guild.id

  let text = ''

  const results = await thanksSchema
    .find({
      guildId: guildId,
    })
    .sort({
      received: -1,
    })
    .limit(10)

  for (let counter = 0; counter < results.length; ++counter) {
    const { userId, received = 0 } = results[counter]

    text += `#${counter + 1} <@${userId}> with **${received} points**\n`
  }

  text += '\nThis is updated every minute'

 




  message.channel.send(new MessageEmbed()
                  .setTitle('Here are the top 10 members with the most points!')
                  .setDescription(text)
    )
      
  
  }
}