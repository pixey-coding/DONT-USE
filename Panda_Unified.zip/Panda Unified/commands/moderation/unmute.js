
module.exports = {

    commands: "unmute",
    description: "UNmute",
    permissions: ['MANAGE_MESSAGES'],
    permissionError: "You need to have the `MANAGE_MESSAGES` permission to run this command!",
    minArgs: 1,
    expectedArgs: "<member-mention>",
    callback: (message, args, text, client) => {
        const member = message.mentions.members.first()
        const role = message.guild.roles.cache.find(r => r.name.toLowerCase() === 'muted')
        if (member.roles.cache.has(role.id)) {
            member.roles.remove(role)
            message.channel.send(`${member} has now been unmuted!`)
            .then(msg => {
                msg.delete({ timeout: 20000 })
            });
    
        }

    }
}
