
const ms = require('ms')
module.exports = {
    commands: "gstart",
    description: "Start a giveaway!",
    permissions: ['MANAGE_GUILD'],
    minArgs: 3,
    expectedArgs: '<time> <winners> <Prize>',
    callback: async(message, args, text, client) => {
        
 
        await client.giveaways.startGiveaway({
            prize: args.slice(2).join(' '),
            channelId: message.channel.id,
            guildId: message.guild.id,
            duration: ms(args[0]),
            winners: parseInt(args[1]),
            hostedBy: message.author.id
        });
    }
}