
const ms = require('ms')
module.exports = {
    commands: "gend",
    description: "End a giveaway!",
    permissions: ['MANAGE_GUILD'],
    minArgs: 1,
    expectedArgs: '<giveaways ID>',
    callback: async(message, arg, text, client) => {
        


const args = message.content.split(' ').slice(1);
const ended = await client.giveaways.endGiveaway(args.join(' '));

if (!ended) {
    return message.channel.send('This giveaway has already ended');
}


    }

}