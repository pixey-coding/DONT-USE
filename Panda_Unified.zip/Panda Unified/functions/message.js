const AntiSpam = require('discord-anti-spam');
const antiSpam = new AntiSpam({
	warnThreshold: 3,
	muteThreshold: 9, 
	maxInterval: 2000, 
	warnMessage: '{@user}, Please stop spamming.', 
	muteMessage: '**{user_tag}** has been muted for spamming.',
	
	maxDuplicatesWarning: 6,

	maxDuplicatesMute: 8, 
	ignoredPermissions: [ 'ADMINISTRATOR', 'MANAGE_GUILD'], 
	ignoreBots: true, 

	
	muteRoleName: "Muted", 
	removeMessages: true 
});
const Fs = require('fs');
const isOurInvite = require('./isOurInvite');
module.exports = (client) => {
    client.on('message', async(message) => {
        let badWords = ["badword", "very bad word", "another bad word"]
        let UserJSON = JSON.parse(Fs.readFileSync("./users.json"));
        antiSpam.message(message)
        if (!UserJSON[message.author.id]) {
          if (message.author.bot) return;
          UserJSON[message.author.id] = {
            warns: 0
          }
          Fs.writeFileSync("./users.json", JSON.stringify(UserJSON));
        }
      for (i = 0; i < badWords.length; i++) {
      if (message.content.toLowerCase().includes(badWords[i])) {
      await message.delete();
      message.reply("no bad words");
      
      
      
      
      
      
      
                  UserJSON[message.author.id].warns += 1;
                  Fs.writeFileSync("./users.json", JSON.stringify(UserJSON));
      
      
      
      if (UserJSON[message.author.id].warns === 3) {
       
      (Fs.readFileSync("./users.json"));
        UserJSON[message.author.id].warns = 0;
        Fs.writeFileSync("./users.json", JSON.stringify(UserJSON));
      
        const user = message.member
        let role = message.guild.roles.cache.find(r => r.name.toLowerCase() === "muted");
      
        user.roles.add(role)
        console.log(`lol i muted ${message.author}`)
      }
              }
          }
      
          isOurInvite(client, message)

    })
}