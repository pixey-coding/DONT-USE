const Discord = require('discord.js')
const db = require('quick.db')

module.exports = {

    commands: "warn",
    description: "Warn a member!",
    minArgs: 2,
    expectedArgs: "<member-mention> <reason>",
    permissions: ['MANAGE_MESSAGES'],
    category: "moderation",
    callback: async(message, arguments, text, client) => {

        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        const target = message.mentions.users.first()


        arguments.shift()

        const guildId = message.guild.id
        const userId = target.id
        const reason = arguments.join(' ')
    
           await  db.push(`${guildId}_${userId}warnsa.reason`, reason)
        
        
        
          const x = client.channels.cache.get('755014032997744722');
          
        const warna = new Discord.MessageEmbed()
            .setTitle(`:warning: | ${target.username}#${target.discriminator} has been Warned!`)
            .addField('Reason', `**\`${reason != "" ? reason : "-"}\`**`, true)
            .addField('Warned By', `*Hidden*`, true)
            .setTimestamp()
            .setFooter('Try Not to do that again..')


            
        message.delete();

        try {

            await user.send(warna)
            message.reply(warna)
           
        } catch {
            message.reply(warna)
            
        }

        
        


    }
}