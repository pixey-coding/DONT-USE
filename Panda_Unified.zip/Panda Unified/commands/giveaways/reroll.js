

const ms = require('ms')
module.exports = {
    commands: "reroll",
    description: "Reroll a giveaway!",
    permissions: ['MANAGE_GUILD'],
    minArgs: 1,
    expectedArgs: '<giveaways ID>',
    callback: async(message, arg, text, client) => {
        

        const args = message.content.split(' ').slice(1);
        const rerolled = await client.giveaways.rerollGiveaway(args.join(' '));
        
        if (!rerolled) {
            return message.channel.send('This giveaway hasn\'t ended');
        }
    

}

}