const Discord = require('discord.js')

module.exports = {
    commands: 'ban',
    category: 'Moderation',
    description: 'Bans the mentioned user or the user which you provided ID from the server lol',
    expectedArgs: `<User-Mention> <Reason>`,
    minArgs: 2,
    permissions: ['BAN_MEMBERS'],
    permissionError: "You do not have the permission to do that lol try asking a staff to give you the permission **`BAN_MEMBERS`** or **`ADMINISTRATOR`**",
    category: "moderation",
    callback: async (message, args, text, client) => {

        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        const perms = ["MANAGE_ROLES" || "ADMINSTRATOR"];
        const doggo = message.guild.members.cache.get(client.user.id);
        const log = client.channels.cache.get('806524112301195334')
        if(!user){
            message.reply(`:x: Are you going crazy or are you trying to ban someone that does not exist?!`)
            return
        }

        if(!message.member.hasPermission(perms)) 
        return message.reply(`:x: You do not have the permission to do that lol try asking a staff to give you the permission **\`BAN_MEMBERS\`** or **\`ADMINISTRATOR\`**`)
        .then(msg => {
            msg.delete({ timeout: 20000 })
        });

        if(!doggo.hasPermission(perms))
        return message.reply(`:x: I do not have permission to ban users pls enable permission **\`BAN_MEMBERS\`** for me`)


        
        if(user.id === message.author.id) 
        return message.reply(`:x: You cannot ban yourself idot`)

        if(user.id === client.user.id)
        return message.reply(`:x: Wait What !!?? I cannot ban myslef !!`)        

        if (user.roles.highest.position >= message.member.roles.highest.position)
        return message.reply(`:x: You cannot ban someone with an equal or higher role to you !!! or if you are owner pls be yourself in a higher position`)
        

        if (!user.bannable)
        return message.reply(`:x: Provided user is not bannable cuz he / she has higher role than me or equal to my position :(`);


        const reason = args.slice(1).join(" ");
        const a = message.guild.members.cache.get(user.id)

       

 
        const embed = new Discord.MessageEmbed()
        .setColor("#00aaaa")
        .setTitle(':hammer: | ban')
        .setDescription(`:white_check_mark: <@${user.id}> (**\`${user.user.tag}\`**) has been banned from **${message.guild.name}**`)
        .addField('Reason', `**\`${reason != "" ? reason : "-"}\`**`, true)
        .addField('Banned By', `<@${message.member.id}> (**\`${message.member.user.tag}\`**)`, true)
        .setFooter('DM sent!')
        .setTimestamp()
         
        const embed2 = new Discord.MessageEmbed()
        .setColor("#00aaaa")
        .setTitle(':hammer: | ban')
        .setDescription(`:white_check_mark: <@${user.id}> (**\`${user.user.tag}\`**) has been banned from **${message.guild.name}**`)
        .addField('Reason', `**\`${reason != "" ? reason : "-"}\`**`, true)
        .addField('Banned By', `<@${message.member.id}> (**\`${message.member.user.tag}\`**)`, true)
        .setFooter('DM not sent!')
        .setTimestamp()
        
        const embed1 = new Discord.MessageEmbed()
        .setColor("#00aaaa")
        .setTitle(':hammer: | ban')
        .setDescription(`:confused: | You have been banned from **${message.guild.name}**`)
        .addField('Reason', `**\`${reason != "" ? reason : "-"}\`**`, true)
        .addField('Banned By', `*someone*`, true)
        .setTimestamp()
         
        try {

            await user.send(embed1)
            message.channel.send(embed);
            log.send(embed)
        } catch {
            message.channel.send(embed2)
            log.send(embed2)
        }

        a.ban({reason: reason});
        
        await message.channel.send(embed);
    }
}