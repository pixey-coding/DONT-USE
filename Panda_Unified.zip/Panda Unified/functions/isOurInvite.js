module.exports = async (client, message) => {
    const isInvite = async (guild, code) => {
      return await new Promise((resolve) => {
        guild.fetchInvites().then((invites) => {
          for (const invite of invites) {
            if (code === invite[0]) {
              resolve(true)
              return
            }
          }
          resolve(false)
        })
      })
    }
  
   
      const { guild, member, content } = message;
      if (member.hasPermission('ADMINISTRATOR')) return
      const DiscordExpression = new RegExp(/(discord\.(gg|io|me|li)|discordapp\.com\/invite)/i);
      const invite = content.split(DiscordExpression)[3];
      if (invite) {
        
      const code = invite.replace(/ ?\//g, "");
      
        console.log(code);
        if (DiscordExpression.test(content)) {
          const isOurInvite = await isInvite(guild, code)
          if (!isOurInvite) {
            await message.delete();
            await message.reply("You are not allowed to send external invite links here.")
          }
        }
      
      }

  }