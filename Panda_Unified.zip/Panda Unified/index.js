const { Client } = require("discord.js");
const config = require('./config.json')
const client = new Client()
const load = require('./commands/load');
const message = require("./functions/message");
const { GiveawayCreator } = require('discord-giveaway');
const mongo = require("./functions/mongo");

const Creator = new GiveawayCreator(client, config.mongoPath);

client.giveaways = Creator;
client.on('ready', async () => {
    await mongo().then(console.log('Connected to db!'))
    console.log('Me is ready!')
    load(client)
    message(client)
})

client.login(config.token)