module.exports = {
    commands: "clean",
  
    category: "Moderation",
    description: "Clears the chat",
    category: "moderation",
    expectedArgs: `<amount to be cleared>`,
    permissions: ["MANAGE_MESSAGES"],
    permissionError: "You can't delete messages.. since you don't have permission to do it ask admin or owner to give you permission **`MANAGE_MESSAGES`** !!",
    callback: async (message, args, text, client) => {

        const perms = ["MANAGE_MESSAGES" || "ADMINSTRATOR"]

        if (message.deletable) {
            message.delete();
        }


        if (!message.guild.me.hasPermission(perms)) {
            return message.reply(`:x: Sorryy... I can't delete messages I don't have permission to do that pls enable permission **\`MANAGE_MESSAGES\`**`)
            .then(msg => {
                msg.delete({ timeout: 15000 })
              })
        }

        if (isNaN(args[0]) || parseInt(args[0]) <= 0) {
            return message.reply(`:x: Please provide a number between 1 & 100 rather than an alphabet, blank space or 0`)
            .then(msg => {
                msg.delete({ timeout: 15000 })
              })
        }

        if (parseInt(args[0]) > 100) 
        return message.reply(`:x: Welp I can only clear \`100\` messages maximum`)
        .then(msg => {
            msg.delete({ timeout: 15000 })
        })

        let deleteAmount = parseInt(args[0]);  

        message.channel.bulkDelete(deleteAmount, true)
            .then(deleted => message.channel.send(`:white_check_mark: I deleted \`${deleted.size}\` messages.`))
            .then(msg => {
                msg.delete({ timeout: 3000 })
              })
            
    }
}