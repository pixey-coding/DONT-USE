const loadCommands = require('../load')
const { prefix } = require('../../config.json')
const { MessageEmbed } = require('discord.js')

module.exports = {
  commands: 'help',
  description: "Describes all of this bot's commands",
  callback: (message, arguments, text) => {
    let reply = ''
    const commands = loadCommands()
    const helpEM = new MessageEmbed() 
                  .setColor('ORANGE')
                  .setTitle('Heres a list of all my commands!')
    for (const command of commands) {
    
 
     
      const mainCommand =
        typeof command.commands === 'string'
          ? command.commands
          : command.commands[0]
      const args = command.expectedArgs ? ` ${command.expectedArgs}` : ''
      const { description } = command

      helpEM.addField(`**${prefix}${mainCommand}${args}**`, `${description}`)
    }

    message.channel.send(helpEM)
  },
}