module.exports = {
    commands: 'ping',
    description: "Replies with pong!",
    callback: (message, args, text, client) => {
       
        message.channel.send('Pong!')
        
    }
}