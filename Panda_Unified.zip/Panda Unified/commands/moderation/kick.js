const Discord = require('discord.js');

module.exports = {
    commands: 'kick',
    category: 'Moderation',
    description: 'Kicks the mentioned user or the user which you provided ID from the server lol',
    expectedArgs: `<user-mention> <reason>`,
    permissions: ['KICK_MEMBERS'],
    category: "moderation",
    minArgs: 2,
    permissionError: "You do not have the permission to do that lol try asking your owner or admin to give you the permission **`KICK_MEMBERS`** or **`ADMINISTRATOR`**",

    callback: async (message, args, text, client) => {
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        const Perms = ["KICK_MEMBERS" || "ADMINSTRATOR"]
        const doggo = message.guild.members.cache.get(client.user.id);
        const logs = client.channels.cache.get('806524112301195334')
        

        if(!message.member.hasPermission(Perms)) 
        return message.reply(`${emoji.Error} You do not have the permission to do that lol try asking your owner or admin to give you the permission **\`KICK_MEMBERS\`** or **\`ADMINISTRATOR\`**`)
        .then(msg => {
            msg.delete({ timeout: 20000 })
        });

        if(!doggo.hasPermission(Perms))
        return message.reply(`:x: I do not have permission to kick users pls enable permission **\`KICK_MEMBERS\`** for me`)

        
        if(user.id === client.user.id)
        return message.reply(`:x: Wait what ??!! I can't kick myself !!!`)

        if(user.id === message.author.id) 
        return message.reply(`:x: You cannot kick yourself idot`)
        

        if (user.roles.highest.position > message.member.roles.highest.position)
        return message.reply(`:x: You cannot kick someone with an equal or higher role to you !!! **or** if you are owner pls be yourself in a higher position`)
        

        if (!user.bannable)
        return message.reply(`:x: Provided user is not kickable cuz he / she has higher role than me or equal as my position :(`);


        const reason = args.slice(1).join(" ");
      
 
        const embed = new Discord.MessageEmbed()
        .setColor("#00aaaa")
        .setTitle(':hiking_boot: | Kick')
        .setDescription(`:white_check_mark: <@${user.id}> (**\`${user.user.tag}\`**) has been kicked from **${message.guild.name}**`)
        .addField('Reason', `**\`${reason != "" ? reason : "-"}\`**`, true)
        .addField('Kicked By', `<@${message.member.id}> (**\`${message.member.user.tag}\`**)`, true)
        .setFooter(`DM sent!`)
        .setTimestamp()

        const embed2 = new Discord.MessageEmbed()
        .setColor("#00aaaa")
        .setTitle(':hiking_boot: | Kick')
        .setDescription(`:white_check_mark: <@${user.id}> (**\`${user.user.tag}\`**) has been kicked from **${message.guild.name}**`)
        .addField('Reason', `**\`${reason != "" ? reason : "-"}\`**`, true)
        .addField('Kicked By', `<@${message.member.id}> (**\`${message.member.user.tag}\`**)`, true)
        .setFooter(`DM not sent!`)
        .setTimestamp()

        const embed1 = new Discord.MessageEmbed()
        .setColor("#00aaaa")
        .setTitle(':hiking_boot: | Kick')
        .setDescription(`😕 | You have been kicked from **${message.guild.name}**`)
        .addField('Reason', `**\`${reason != "" ? reason : "-"}\`**`, true)
        .addField('Kicked By', `*Someone*`, true)
        .setTimestamp()
        
        try {

            await user.send(embed1)
            message.channel.send(embed);
            logs.send(embed)
        } catch {
            message.channel.send(embed2)
            logs.send(embed2)
        }
        
        user.kick({reason: reason});
    }
}