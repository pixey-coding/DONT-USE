const Discord = require('discord.js')
module.exports = {
    commands: 'poll',

    expectedArgs: 'Question | Choice 1 | Choice 2 | Choice 3 | Choix 4 ',
     description: "Start a new poll!",
    callback: async (message, args) => {
        const reactions = ['🇦', '🇧', '🇨', '🇩', '🇪', '🇫', '🇬', '🇭', '🇮', '🇯', '🇰', '🇱', '🇲', '🇳', '🇴', '🇵', '🇶', '🇷', '🇸', '🇹']
        const client = message.client;
        const [question, ...choices] = args.join(' ').split(' | ')
        if (!question) return message.reply("You've got to create a question for you poll")
        if (!choices.length) return message.reply("Your poll has to have at least one choice !")
        if (choices.length > 20) return message.reply("Your poll can't have more than 20 choices !")
        message.delete()
        const sent = await message.channel.send(new Discord.MessageEmbed()
            .setTitle('New poll !')
            .setColor('#e6dfd1')
            .setTimestamp()
           
            .setAuthor(message.author.username, message.author.displayAvatarURL())
            .setDescription(`${message.author} created a poll !\n\n **${question}**\n` + choices.map((choice, i) => `${reactions[i]} ${choice}`).join('\n'))
      
        )
        for (i = 0; i < choices.length; i++) await sent.react(reactions[i])
    }

}